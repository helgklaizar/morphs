import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type Locale = 'ru' | 'en' | 'he' | 'uk';

interface LocaleState {
  locale: Locale;
  hasPicked: boolean;
  setLocale: (loc: Locale) => void;
}

export const useLocaleStore = create<LocaleState>()(
  persist(
    (set) => ({
      locale: 'ru',
      hasPicked: false,
      setLocale: (loc) => set({ locale: loc, hasPicked: true }),
    }),
    {
      name: 'locale-storage',
    }
  )
);

export const translate = (loc: string, ru: string, en?: string, he?: string, uk?: string) => {
  if (loc === 'he' && he && he.trim() !== '') return he;
  if (loc === 'uk' && uk && uk.trim() !== '') return uk;
  if (loc === 'en' && en && en.trim() !== '') return en;
  return ru;
};
